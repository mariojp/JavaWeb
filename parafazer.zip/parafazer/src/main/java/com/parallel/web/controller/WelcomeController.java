/**
 * 
 */
package com.parallel.web.controller;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import com.parallel.business.model.HelloWorld;
import com.parallel.service.HelloWorldService;
import com.parallel.service.dto.HelloWorldDTO;
import com.parallel.util.LoggerUtils;
import com.parallel.util.MapperUtils;
import com.parallel.web.form.HelloWorldForm;

/**
 * Welcome controller.
 * 
 * @author mariojp
 */
@ManagedBean
public class WelcomeController {



	/**
	 * {@link HelloWorldService}
	 */
	@ManagedProperty(value = HelloWorldService.EL_NAME)
	private HelloWorldService helloWorldService;

	/**
	 * {@link HelloWorldService}
	 */
	@ManagedProperty(value = HelloWorldForm.EL_NAME)
	private HelloWorldForm helloWorldForm;


	/**
	 * List of hellos
	 */
	private List<HelloWorldDTO> listHellos;


	public String createHello() {
		helloWorldService.create((HelloWorld) MapperUtils.map(helloWorldForm, HelloWorld.class));
		return "welcome?faces-redirect=true";
	}

	/**
	 * Retrieve hello dto
	 * 
	 * @return list of hello dto
	 */
	public List<HelloWorldDTO> retrieveList() {
		// Prevent multiple calls from JSF
		if (listHellos == null) {
			LoggerUtils.logDebug("Initialize hello world list for display");
			listHellos = helloWorldService.retrieveAll();
		}
		return listHellos;
	}


	public void setHelloWorldForm(HelloWorldForm helloWorldForm) {
		this.helloWorldForm = helloWorldForm;
	}

	public HelloWorldService getHelloWorldService() {
		return helloWorldService;
	}

	public void setHelloWorldService(HelloWorldService helloWorldService) {
		this.helloWorldService = helloWorldService;
	}

}
