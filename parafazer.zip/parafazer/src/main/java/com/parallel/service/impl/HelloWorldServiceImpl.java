/**
 * 
 */
package com.parallel.service.impl;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.parallel.business.model.HelloWorld;
import com.parallel.business.persistence.HelloWorldDao;
import com.parallel.service.HelloWorldService;
import com.parallel.service.dto.HelloWorldDTO;
import com.parallel.util.LoggerUtils;
import com.parallel.util.MapperUtils;

/**
 * Implementation of {@link HelloWorldService}
 * 
 * @author mariojp
 */
@Named(HelloWorldService.BEAN_NAME)
public class HelloWorldServiceImpl implements HelloWorldService {

	/* ************************************ */
	/* Dependencies */
	/* ************************************ */

	/**
	 * {@link HelloWorldDao}
	 */
	@Inject
	private HelloWorldDao helloWorldDao;

	/* ************************************ */
	/* Methods */
	/* ************************************ */

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void create(HelloWorld entity) {
		LoggerUtils.logStartMethod("create");
		helloWorldDao.create(entity);
		LoggerUtils.logEndMethod("create");
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public List<HelloWorldDTO> retrieveAll() {
		LoggerUtils.logStartMethod("retrieveAll");
		List<HelloWorld> listEntities = helloWorldDao.retrieveAll();
		@SuppressWarnings("unchecked")
		List<HelloWorldDTO> returnValue = (List<HelloWorldDTO>) MapperUtils.mapAsList(listEntities, HelloWorldDTO.class);
		LoggerUtils.logEndMethod("retrieveAll");
		return returnValue;
	}

}
