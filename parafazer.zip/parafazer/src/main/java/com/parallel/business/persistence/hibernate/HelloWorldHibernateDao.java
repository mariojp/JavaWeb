/**
 * 
 */
package com.parallel.business.persistence.hibernate;

import javax.inject.Named;

import com.parallel.business.model.HelloWorld;
import com.parallel.business.persistence.HelloWorldDao;
import com.parallel.common.persistence.hibernate.BusinessHibernateDao;

/**
 * Hibernate implementation of {@link HelloWorldDao}
 * 
 * @author mariojp
 */
@Named
public class HelloWorldHibernateDao extends BusinessHibernateDao<HelloWorld> implements HelloWorldDao {

}
