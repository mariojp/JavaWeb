/**
 * 
 */
package com.parallel.business.persistence;

import com.parallel.business.model.HelloWorld;
import com.parallel.common.persistence.BusinessDao;

/**
 * DAO of HelloWorld
 * 
 * @author mariojp
 */
public interface HelloWorldDao extends BusinessDao<HelloWorld> {

}
